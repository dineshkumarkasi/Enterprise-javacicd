# A simple jenkins pipeline to verify if the docker slave configuration is working as expected.
